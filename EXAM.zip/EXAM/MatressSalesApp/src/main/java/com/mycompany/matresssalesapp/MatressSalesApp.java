/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.matresssalesapp;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
/**
 *
 * @author MrChromebookSolution
 */
public class MatressSalesApp extends JFrame {
    
    private final JTextField txtCustomerName = new JTextField(20);
    private final JComboBox<String> cmbProduct = new JComboBox<>(new String[]{ "Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"});
    private final JTextField txtPrice = new JTextField(20);
    private final JTextField txtVat = new JTextField(20);
    private final JTextField txtCommission = new JTextField(20);
    private final JTextField txtTotal = new JTextField(20);
    private final JButton btnProcess = new JButton("Process");
    
    public MatressSalesApp() {
        setTitle("Mattress Sales");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        txtVat.setEditable(false);
        txtCommission.setEditable(false);
        txtTotal.setEditable(false);
 
       BuildMenu();
       BuildForm();
 
     btnProcess.addActionListener(e -> ProcessSale());
 
     pack();
     setLocationRelativeTo(null); // centre on screen
 }
    
    private void BuildMenu() {
      JMenuBar menuBar = new JMenuBar();
    
      JMenu fileMenu = new JMenu("File");
      JMenuItem exitItem = new JMenuItem("Exit");
      exitItem.addActionListener(e -> System.exit(0));
      fileMenu.add(exitItem);
    
      JMenu toolsMenu = new JMenu("Tools");
      JMenuItem processItem = new JMenuItem("Process");
      processItem.addActionListener(e -> ProcessSale()); // same logic as button
      JMenuItem clearItem = new JMenuItem("Clear");
      clearItem.addActionListener(e -> ClearForm());
      toolsMenu.add(processItem);
      toolsMenu.add(clearItem);
    
      menuBar.add(fileMenu);
      menuBar.add(toolsMenu);
     setJMenuBar(menuBar);
  }
    private void BuildForm() {
      JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
      form.setBorder(BorderFactory.createEmptyBorder(15, 15, 5, 15));
      
      form.add(new JLabel("Customer Name:")); form.add(txtCustomerName);
      form.add(new JLabel("Product Name:")); form.add(cmbProduct);
      form.add(new JLabel("Product Price (R):")); form.add(txtPrice);
      
      form.add(new JLabel("VAT Amount:")); form.add(txtVat);
      form.add(new JLabel("Commission Amount:")); form.add(txtCommission);
      form.add(new JLabel("Total Sale Amount:")); form.add(txtTotal);
      
      JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
      buttonPanel.add(btnProcess);
      
      add(form, BorderLayout.CENTER);
      add(buttonPanel, BorderLayout.SOUTH);
 }
    
    // Q2.3 - used by BOTH the button and the Tools > Process menu item
    private void ProcessSale() {
    String customerName = txtCustomerName.getText().trim();
    String productName = (String) cmbProduct.getSelectedItem();
    
    if (customerName.isEmpty()) {
       JOptionPane.showMessageDialog(this, "Please enter the customer name.","Missing data", JOptionPane.WARNING_MESSAGE);
    return;
 }
    
    double price;
    try {
        price = Double.parseDouble(txtPrice.getText().trim());
   } catch (NumberFormatException ex) {
       JOptionPane.showMessageDialog(this, "Please enter a valid price, e.g. 5000.00","Invalid price", JOptionPane.ERROR_MESSAGE);
       return;
 }
    if (price <= 0) {
       JOptionPane.showMessageDialog(this, "The price must be greater than zero.", "Invalid price", JOptionPane.ERROR_MESSAGE);
     return;
 }
    IProductCalculations calc = new ProductCalculations(price);
    double vat = calc.GetVat();
    double commission = calc.GetCommission();
    double total = calc.GetTotal();
   
   txtVat.setText(String.format(Locale.US, "%.2f", vat));
   txtCommission.setText(String.format(Locale.US, "%.2f", commission));
   txtTotal.setText(String.format(Locale.US, "%.2f", total));
   
   SaveToFile(customerName, productName, vat, commission, total);
 }
    
    // Writes one record to data.txt (true = append, so earlier sales are kept)
    private void SaveToFile(String customer, String product,double vat, double commission, double total) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("data.txt", true))) {
            writer.write("Data Log");
            writer.newLine();
            writer.write("***************************");
             writer.write("Customer Name: " + customer);
             writer.newLine();
             writer.write("Product: " + product);
             writer.newLine();
             writer.write(String.format(Locale.US, "VAT: R%.2f", vat));
             writer.newLine();
             writer.write(String.format(Locale.US, "Commission: R%.2f", commission));
             writer.newLine();
             writer.write(String.format(Locale.US, "Total: R%.2f", total));
             writer.newLine();
             writer.newLine();
             writer.write("**************************");
             writer.newLine();
             writer.newLine(); // blank line between records
        } catch (IOException ex) {
           JOptionPane.showMessageDialog(this, "Could not save to data.txt: " + ex.getMessage(), "File error", JOptionPane.ERROR_MESSAGE);
       }
 }
    
    private void ClearForm() {
    txtCustomerName.setText("");
    txtPrice.setText("");
    txtVat.setText("");
    txtCommission.setText("");
    txtTotal.setText("");
    cmbProduct.setSelectedIndex(0);
    txtCustomerName.requestFocus();
 }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MatressSalesApp().setVisible(true));
    }
}
