/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.matresssalesreport;

/**
 *
 * @author MrChromebookSolution
 */
public class Product implements IProduct {
    private final String[] productNames; // single array
    private final int[][] sales; // 2D array [product][month]
    
 public Product(String[] productNames, int[][] sales) {
     this.productNames = productNames;
     this.sales = sales;
 }
     // Single array holding each product's total over all months
     private int[] GetProductTotals() {
     int[] totals = new int[sales.length];
         for (int p = 0; p < sales.length; p++) {
             for (int m = 0; m < sales[p].length; m++) {
                  totals[p] += sales[p][m];
                }
    }
     return totals;
     }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int productTotal : GetProductTotals()) {
             total += productTotal;
        }
        return total;
    }

    @Override
    public double GetAverageProductSold() {
        // cast to double so Java does NOT do integer division
        return (double) GetTotalProductsSold() / productNames.length;
    }

    @Override
    public String GetMostPopularProduct() {
        int[] totals = GetProductTotals();
        int highestIndex = 0;
        for (int p = 1; p < totals.length; p++) {
             if (totals[p] > totals[highestIndex]) {
                 highestIndex = p;
             }
    }
     return productNames[highestIndex];
    }
    
}
