/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.matresssalesreport;

/**
 *
 * @author MrChromebookSolution
 */
public class MatressSalesReport {

    public static void main(String[] args) {
        
        String[] productNames = {"Cozy Nights Monarch Matress" , "Restonic Barbados Matress" , "Sealy Phuket Matress"};
        
        // rows = products, columns = months 1 to 3
        int[][] sales = {
           {25, 18, 20},
           { 15, 10, 12},
           {18, 15, 20}
        };
        
        Product product = new Product(productNames, sales);
        PrintProduct printer = new PrintProduct(product);
        
        System.out.println("===== MATTRESS SALES REPORT =====");
        printer.PrintTotalProductSales();
        printer.PrintAverageProductSales();
        printer.PrintMostPopularProduct();

    }
}
